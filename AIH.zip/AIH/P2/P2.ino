const int gsrPin = A0;

int thresholdLow = 300;
int thresholdHigh = 600;

const int numSamples = 10;   // number of samples for averaging

void setup() {
  Serial.begin(115200);
  Serial.println("GSR Monitoring Started...");
}

void loop() {

  long sum = 0;

  // Take multiple readings
  for (int i = 0; i < numSamples; i++) {
    sum += analogRead(gsrPin);
    delay(5);  // small delay between samples
  }

  int gsrValue = sum / numSamples;  // average value

  // Print averaged value
  Serial.print("GSR Avg Value: ");
  Serial.print(gsrValue);

  // Stress classification
  if (gsrValue < thresholdLow) {
    Serial.println("  --> Relaxed");
  } 
  else if (gsrValue <= thresholdHigh) {
    Serial.println("  --> Normal");
  } 
  else {
    Serial.println("  --> Stressed");
  }

  delay(100);
}
