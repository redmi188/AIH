const int emgPin = A0;
const int samples = 10;

void setup() {
  Serial.begin(115200);
}

void loop() {
  long sum = 0;

  for (int i = 0; i < samples; i++) {
    sum += analogRead(emgPin);
  }

  int emgAvg = sum / samples;
  Serial.println(emgAvg);

  delay(5);
}
