const int gsrPin = A0;

void setup() {
  Serial.begin(9600);
}

void loop() {
  //int gsrValue = 500;
  int gsrValue = analogRead(A0);
  Serial.println(gsrValue);
  delay(100);
}
