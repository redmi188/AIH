#include <SoftwareSerial.h>
#include "thingProperties.h"

// RX, TX (ESP side)
SoftwareSerial mySerial(D6, D7);  // D6 = RX, D7 = TX

void setup() {
  Serial.begin(115200);      // For monitor
  mySerial.begin(9600);      // For UNO

  initProperties();
  ArduinoCloud.begin(ArduinoIoTPreferredConnection);
}

void loop() {
  ArduinoCloud.update();

  if (mySerial.available()) {
    int gsrValueLocal = mySerial.parseInt();

    Serial.print("Received: ");
    Serial.println(gsrValueLocal);

    if (gsrValueLocal > 0) {
      GSR = gsrValueLocal;

      Serial.print("ESP GSR: ");
      Serial.println(GSR);

      if (GSR > 600) {
        Stress_level = "Relaxed";
      } 
      else if (GSR > 300) {
        Stress_level = "Normal";
      } 
      else {
        Stress_level = "Stressed";
      }
    }
  }
}

void onGSRChange() {}
void onStressLevelChange() {}
