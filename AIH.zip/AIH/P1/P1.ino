const int ecgPin = A0;
const int loPlus = 10;
const int loMinus = 11;

const int numSamples = 10;

void setup() {
  Serial.begin(115200);
  pinMode(loPlus, INPUT);
  pinMode(loMinus, INPUT);
}

void loop() {

  // Check electrode connection
  if (digitalRead(loPlus) == 1 || digitalRead(loMinus) == 1) {
    Serial.println("Leads Off!");
    return;
  }

  long sum = 0;

  // Averaging for noise reduction
  for (int i = 0; i < numSamples; i++) {
    sum += analogRead(ecgPin);
    delay(2);
  }

  int ecgValue = sum / numSamples;

  Serial.println(ecgValue);

  delay(5);  // ~200 Hz sampling
}
